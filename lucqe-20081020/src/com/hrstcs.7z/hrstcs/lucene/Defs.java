/*
 * Defs.java
 *
 * Created on October 25, 2004, 6:31 PM
 */

package com.hrstcs.lucene;

/**
 *
 * @author  wani
 */
public class Defs
{
    
public static final String FLD_TEXT = "text";

public static final String RUN_TAG_FLD = "run.tag";

}
